--[[
LEICA Q3 DIGITAL ZOOM CROP — Lightroom Classic Plugin

Detects Q3 digital zoom from DNG DefaultCrop metadata and applies
a matching centred crop in Develop. The crop fraction is stored in
the IPTC "Instructions" field so it can be re-applied after a Reset
via the companion "Re-apply" menu item.

Menu: Library > Plug-in Extras > Apply Q3 Digital Zoom Crop
--]]

local LrApplication     = import "LrApplication"
local LrDialogs         = import "LrDialogs"
local LrFunctionContext = import "LrFunctionContext"
local LrTasks           = import "LrTasks"
local LrView            = import "LrView"

local FRACTION_TAG = "Q3Crop:"   -- prefix written into IPTC Instructions

local ZOOM_LEVELS = {
    { label = "1.25x - 35mm", fraction = 0.800, tol = 0.04, mp = "39MP" },
    { label = "1.80x - 50mm", fraction = 0.556, tol = 0.04, mp = "19MP" },
    { label = "2.70x - 75mm", fraction = 0.370, tol = 0.04, mp = "8MP"  },
    { label = "3.20x - 90mm", fraction = 0.313, tol = 0.04, mp = "6MP"  },
}

local function detectZoom(photo)
    local maker = (photo:getFormattedMetadata("cameraMake")  or ""):lower()
    local model = (photo:getFormattedMetadata("cameraModel") or ""):lower()
    if not (maker:find("leica") and model:find("leica q3")) then
        return nil, "Not a Leica Q3 image"
    end

    local dims    = photo:getRawMetadata("dimensions")
    local cropped = photo:getRawMetadata("croppedDimensions")

    if not dims    or dims.width    == 0 then return nil, "Sensor dimensions unavailable" end
    if not cropped or cropped.width == 0 then return nil, "Cropped dimensions unavailable" end

    local fraction = cropped.width / dims.width

    if fraction > 0.97 then
        return nil, string.format("Native 28mm - no zoom (%dx%d, 60MP)", cropped.width, cropped.height)
    end

    for _, level in ipairs(ZOOM_LEVELS) do
        if math.abs(fraction - level.fraction) <= level.tol then
            return level, cropped.width, cropped.height
        end
    end

    return nil, string.format("Unrecognised fraction %.3f (%dx%d)", fraction, cropped.width, cropped.height)
end

local function applyCropSettings(photo, fraction)
    local half = (1.0 - fraction) / 2.0
    photo:applyDevelopSettings({
        CropLeft   = half,
        CropTop    = half,
        CropRight  = 1.0 - half,
        CropBottom = 1.0 - half,
        CropAngle  = 0,
    })
end

local function storeFraction(photo, fraction, label)
    -- Prepend our tag to whatever is already in Instructions, avoiding duplicates
    local existing = photo:getFormattedMetadata("instructions") or ""
    -- Strip any previous Q3Crop entry
    existing = existing:gsub(FRACTION_TAG .. "[%d%.]+%s*", "")
    existing = existing:gsub("^%s*", "")
    local newVal = FRACTION_TAG .. string.format("%.4f", fraction)
    if #existing > 0 then newVal = newVal .. " " .. existing end
    photo:setRawMetadata("instructions", newVal)
end

local function run()
    local catalog   = LrApplication.activeCatalog()
    local selection = catalog:getTargetPhotos()

    if not selection or #selection == 0 then
        LrDialogs.message("Leica Q3 Digital Zoom",
            "Select one or more Leica Q3 DNG files first.", "info")
        return
    end

    local results = {}
    for _, photo in ipairs(selection) do
        local name           = photo:getFormattedMetadata("fileName") or "?"
        local level, cw, ch  = detectZoom(photo)
        results[#results + 1] = {
            photo  = photo,
            name   = name,
            level  = level,
            status = level
                and string.format("+ %s  (%dx%d, %s)", level.label, cw, ch, level.mp)
                or  ("! " .. (cw or "error")),
        }
    end

    LrFunctionContext.callWithContext("LeicaQ3DZ", function(_ctx)
        local f = LrView.osFactory()

        local rows = {
            f:row {
                f:static_text { title = "File",          font = "<system/bold>", width = 200 },
                f:static_text { title = "Detected zoom", font = "<system/bold>", width = 340 },
            },
            f:separator { fill_horizontal = 1 },
        }

        local applyCount = 0
        for _, r in ipairs(results) do
            if r.level then applyCount = applyCount + 1 end
            rows[#rows + 1] = f:row {
                spacing = f:control_spacing(),
                f:static_text { title = r.name,   width = 200 },
                f:static_text { title = r.status, width = 340 },
            }
        end

        rows[#rows + 1] = f:separator { fill_horizontal = 1 }
        rows[#rows + 1] = f:static_text {
            title = applyCount > 0
                and string.format(
                    "Crop will be applied to %d image%s.\n"..
                    "Fraction stored in IPTC Instructions — use\n"..
                    "Plug-in Extras > Re-apply Q3 Crop to restore after a Reset.",
                    applyCount, applyCount == 1 and "" or "s")
                or "No Q3 digital zoom crops detected.",
            font = "<system/small>",
        }

        local contents = f:column {
            spacing = f:dialog_spacing(),
            f:static_text { title = "Leica Q3 Digital Zoom Crop", font = "<system/bold>" },
            unpack(rows),
        }

        local action = LrDialogs.presentModalDialog {
            title      = "Leica Q3 Digital Zoom",
            contents   = contents,
            actionVerb = applyCount > 0 and "Apply" or "OK",
            cancelVerb = applyCount > 0 and "Cancel" or "<hide>",
        }

        if action ~= "ok" or applyCount == 0 then return end

        local applied = 0
        catalog:withWriteAccessDo("Apply Q3 zoom crops", function()
            for _, r in ipairs(results) do
                if r.level then
                    applyCropSettings(r.photo, r.level.fraction)
                    storeFraction(r.photo, r.level.fraction, r.level.label)
                    applied = applied + 1
                end
            end
        end)

        LrDialogs.showBezel(string.format("Cropped %d image%s",
            applied, applied == 1 and "" or "s"))
    end)
end

LrTasks.startAsyncTask(run)
