return {
    LrSdkVersion        = 6.0,
    LrSdkMinimumVersion = 6.0,
    LrToolkitIdentifier = "com.leica.q3.digitalzoom",
    LrPluginName        = "Leica Q3 Digital Zoom",

    LrLibraryMenuItems = {
        {
            title = "Apply Q3 Digital Zoom Crop",
            file  = "LeicaQ3DigitalZoom.lua",
        },
        {
            title = "Re-apply Q3 Digital Zoom Crop (after Reset)",
            file  = "LeicaQ3Reapply.lua",
        },
    },

    LrExportMenuItems = {
        {
            title = "Apply Q3 Digital Zoom Crop",
            file  = "LeicaQ3DigitalZoom.lua",
        },
        {
            title = "Re-apply Q3 Digital Zoom Crop (after Reset)",
            file  = "LeicaQ3Reapply.lua",
        },
    },

    LrHelpMenuItems = {
        {
            title = "Apply Q3 Digital Zoom Crop",
            file  = "LeicaQ3DigitalZoom.lua",
        },
    },

    LrPluginInfoProvider = "PluginInfoProvider",

    VERSION = { major = 2, minor = 2, revision = 0 },
}
