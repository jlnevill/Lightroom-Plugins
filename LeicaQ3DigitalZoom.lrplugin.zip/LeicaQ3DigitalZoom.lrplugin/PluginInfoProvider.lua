--[[
  Required by some Lightroom Classic versions to activate menu items.
--]]
local LrView = import "LrView"

local function sectionsForTopOfDialog(f, propertyTable)
    return {
        {
            title = "Leica Q3 Digital Zoom Crop",
            f:static_text {
                title = "Use Library > Plug-in Extras to apply or re-apply the Q3 digital zoom crop.",
                width = 400,
            },
        },
    }
end

return {
    sectionsForTopOfDialog = sectionsForTopOfDialog,
}
