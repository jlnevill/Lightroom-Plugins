--[[
LEICA Q3 DIGITAL ZOOM — Re-apply after Reset
Reads the crop fraction stored in IPTC Instructions and re-applies the crop.
--]]

local LrApplication = import "LrApplication"
local LrDialogs     = import "LrDialogs"
local LrTasks       = import "LrTasks"

local FRACTION_TAG  = "Q3Crop:"

local function run()
    local catalog   = LrApplication.activeCatalog()
    local selection = catalog:getTargetPhotos()

    if not selection or #selection == 0 then
        LrDialogs.message("Re-apply Q3 Crop", "Select one or more photos first.", "info")
        return
    end

    local toApply = {}
    local noData  = {}

    for _, photo in ipairs(selection) do
        local name         = photo:getFormattedMetadata("fileName") or "?"
        local instructions = photo:getFormattedMetadata("instructions") or ""
        local fracStr      = instructions:match(FRACTION_TAG .. "([%d%.]+)")
        local fraction     = tonumber(fracStr)
        if fraction and fraction > 0.1 and fraction < 1.0 then
            toApply[#toApply + 1] = { photo = photo, fraction = fraction, name = name }
        else
            noData[#noData + 1] = name
        end
    end

    if #toApply == 0 then
        LrDialogs.message("Re-apply Q3 Crop",
            "No Q3 crop data found. Run 'Apply Q3 Digital Zoom Crop' first.\n\n"..
            "No data in: " .. table.concat(noData, ", "), "info")
        return
    end

    local applied = 0
    catalog:withWriteAccessDo("Re-apply Q3 zoom crops", function()
        for _, item in ipairs(toApply) do
            local half = (1.0 - item.fraction) / 2.0
            item.photo:applyDevelopSettings({
                CropLeft   = half,
                CropTop    = half,
                CropRight  = 1.0 - half,
                CropBottom = 1.0 - half,
                CropAngle  = 0,
            })
            applied = applied + 1
        end
    end)

    LrDialogs.showBezel(string.format("Re-applied crop to %d image%s",
        applied, applied == 1 and "" or "s"))
end

LrTasks.startAsyncTask(run)
