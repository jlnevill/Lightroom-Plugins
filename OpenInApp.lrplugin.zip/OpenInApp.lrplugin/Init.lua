-- Init.lua
-- Called once when the plugin loads. Sets default prefs if not already set.

local LrPrefs = import "LrPrefs"

local prefs = LrPrefs.prefsForPlugin()

if prefs.appPath == nil or prefs.appPath == "" then
    if WIN_ENV then
        -- Default: darktable on Windows
        prefs.appPath = "C:\\Program Files\\darktable\\bin\\darktable.exe"
    else
        -- Default: darktable on macOS
        prefs.appPath = "/Applications/darktable.app/Contents/MacOS/darktable"
    end
end

if prefs.extraArgs == nil then
    prefs.extraArgs = ""
end
