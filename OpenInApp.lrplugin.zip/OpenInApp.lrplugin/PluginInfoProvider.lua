-- PluginInfoProvider.lua
-- Adds a configuration panel to File › Plug-in Manager.

local LrView  = import "LrView"
local LrPrefs = import "LrPrefs"
local LrDialogs = import "LrDialogs"
local LrPathUtils = import "LrPathUtils"

local prefs = LrPrefs.prefsForPlugin()

local function sectionsForTopOfDialog(f, _)
    local bind = LrView.bind

    return {
        {
            title = "External Application",

            f:row {
                spacing = f:label_spacing(),
                f:static_text {
                    title = "App path:",
                    alignment = "right",
                    width = LrView.share "label_width",
                },
                f:edit_field {
                    value = bind { key = "appPath", bind_to_object = prefs },
                    width_in_chars = 50,
                    tooltip = "Full path to the executable (e.g. /Applications/darktable.app/Contents/MacOS/darktable)",
                },
                f:push_button {
                    title = "Browse…",
                    action = function()
                        local path = LrDialogs.runOpenPanel {
                            title = "Choose Application",
                            canChooseFiles = true,
                            canChooseDirectories = false,
                            allowsMultipleSelection = false,
                        }
                        if path and path[1] then
                            -- On macOS the user may pick the .app bundle; resolve the
                            -- actual binary automatically.
                            local chosen = path[1]
                            if chosen:match("%.app$") then
                                local name = LrPathUtils.removeExtension(LrPathUtils.leafName(chosen))
                                local binary = chosen .. "/Contents/MacOS/" .. name
                                local LrFileUtils = import "LrFileUtils"
                                if LrFileUtils.exists(binary) then
                                    chosen = binary
                                end
                            end
                            prefs.appPath = chosen
                        end
                    end,
                },
            },

            f:row {
                spacing = f:label_spacing(),
                f:static_text {
                    title = "Extra args:",
                    alignment = "right",
                    width = LrView.share "label_width",
                },
                f:edit_field {
                    value = bind { key = "extraArgs", bind_to_object = prefs },
                    width_in_chars = 50,
                    tooltip = "Optional extra command-line arguments inserted before the file paths (e.g. --library :memory:)",
                },
            },

            f:row {
                f:static_text {
                    title = "Examples: darktable, Capture One, RawTherapee, Pixelmator Pro, Preview",
                    font = "<system/small>",
                },
            },
        },
    }
end

return {
    sectionsForTopOfDialog = sectionsForTopOfDialog,
}
