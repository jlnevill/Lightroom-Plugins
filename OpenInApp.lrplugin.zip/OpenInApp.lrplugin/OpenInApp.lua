local LrApplication = import "LrApplication"
local LrDialogs     = import "LrDialogs"
local LrFileUtils   = import "LrFileUtils"
local LrPathUtils   = import "LrPathUtils"
local LrPrefs       = import "LrPrefs"
local LrTasks       = import "LrTasks"
local LrShell       = import "LrShell"

local RAW_EXTENSIONS = {
    arw=true, cr2=true, cr3=true, crw=true, dcr=true, dng=true,
    erf=true, fff=true, mef=true, mos=true, mrw=true, nef=true,
    nrw=true, orf=true, pef=true, ptx=true, r3d=true, raf=true,
    raw=true, rw2=true, rwl=true, sr2=true, srf=true, srw=true,
    x3f=true, ["3fr"]=true, tif=true, tiff=true,
}

local function isRaw(path)
    local ext = LrPathUtils.extension(path):lower()
    return RAW_EXTENSIONS[ext] == true
end

local function quoteAs(p)
    return '"' .. p:gsub('\\', '\\\\'):gsub('"', '\\"') .. '"'
end

-- Return expected TIFF output path for a given raw path
-- Iridient saves as <basename>.tif alongside the raw by default
local function expectedTiff(rawPath)
    local dir  = LrPathUtils.parent(rawPath)
    local base = LrPathUtils.removeExtension(LrPathUtils.leafName(rawPath))
    return LrPathUtils.child(dir, base .. ".tif")
end

LrTasks.startAsyncTask(function()
    local prefs   = LrPrefs.prefsForPlugin()
    local appPath = prefs.appPath or ""

    if appPath == "" then
        LrDialogs.message("Open in External App",
            "No application path configured.\n\nOpen File > Plug-in Manager > Open in External App to set it.",
            "critical")
        return
    end

    local catalog = LrApplication.activeCatalog()
    local photos  = catalog:getTargetPhotos()
    local paths   = {}

    for _, photo in ipairs(photos) do
        local path = photo:getRawMetadata("path")
        if path and isRaw(path) then
            table.insert(paths, path)
        end
    end

    if #paths == 0 then
        LrDialogs.message("Open in External App",
            "No raw files among selection.", "informational")
        return
    end

    -- Snapshot which TIFFs already exist before launching
    local tiffsBefore = {}
    for _, p in ipairs(paths) do
        local tiff = expectedTiff(p)
        tiffsBefore[tiff] = LrFileUtils.exists(tiff)
    end

    -- Launch via AppleScript
    local asFiles = {}
    for _, p in ipairs(paths) do
        table.insert(asFiles, "POSIX file " .. quoteAs(p))
    end

    local script = string.format(
        'tell application %s\nactivate\nopen {%s}\nend tell',
        quoteAs(appPath),
        table.concat(asFiles, ", ")
    )

    local tmpAs = LrPathUtils.getStandardFilePath("temp") .. "/lr_openinapp.applescript"
    local fh = io.open(tmpAs, "w")
    if not fh then
        LrDialogs.message("Open in External App", "Could not write temp file.", "critical")
        return
    end
    fh:write(script)
    fh:close()

    LrShell.openFilesInApp({ tmpAs }, "/usr/bin/osascript")

    -- Wait for app to launch then poll for it to quit
    LrTasks.sleep(3)
    local appName = LrPathUtils.removeExtension(LrPathUtils.leafName(appPath))

    while true do
        local fh2 = io.popen('pgrep -x ' .. quoteAs(appName) .. ' > /dev/null 2>&1; echo $?')
        if fh2 then
            local result = fh2:read("*n")
            fh2:close()
            if result ~= 0 then break end
        else
            break
        end
        LrTasks.sleep(2)
    end

    -- Find any new TIFFs that appeared since we launched
    local newTiffs = {}
    for _, p in ipairs(paths) do
        local tiff = expectedTiff(p)
        if LrFileUtils.exists(tiff) and not tiffsBefore[tiff] then
            table.insert(newTiffs, tiff)
        end
    end

    if #newTiffs == 0 then
        return  -- nothing to import
    end

    -- Add new TIFFs to catalog
    catalog:withWriteAccessDo("Import TIFFs from external edit", function()
        for _, tiffPath in ipairs(newTiffs) do
            catalog:addPhoto(tiffPath)
        end
    end)

    local noun = #newTiffs == 1 and "file" or "files"
    LrDialogs.message("Open in External App",
        string.format("Imported %d new TIFF %s into catalog.", #newTiffs, noun),
        "informational")
end)
