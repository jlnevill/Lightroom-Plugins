return {
    LrSdkVersion        = 6.0,
    LrSdkMinimumVersion = 5.0,

    LrToolkitIdentifier = "com.yourname.openinapp",
    LrPluginName        = "Open in External App",
    LrPluginInfoUrl     = "",

    LrInitPlugin        = "Init.lua",

    LrExportMenuItems = {
        {
            title       = "Open Selected in External App",
            file        = "OpenInApp.lua",
            enabledWhen = "photosSelected",
        },
    },

    LrContextMenuItems = {
        {
            title       = "Open in External App",
            file        = "OpenInApp.lua",
            enabledWhen = "photosSelected",
        },
    },

    LrPluginInfoProvider = "PluginInfoProvider.lua",

    VERSION = { major = 1, minor = 0, revision = 0 },
}
